﻿#if !UNITY_2018_4_OR_NEWER
using System.Reflection;
using System.Runtime.InteropServices;

[assembly: AssemblyTitle("quantum.code")]
[assembly: AssemblyDescription("")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("")]
[assembly: AssemblyProduct("quantum.code")]
[assembly: AssemblyCopyright("")]
[assembly: AssemblyTrademark("")]
[assembly: AssemblyCulture("")]
[assembly: ComVisible(false)]
[assembly: Guid("fbf32099-b197-4ab9-8e5a-b44d9d3750bd")]
[assembly: AssemblyVersion("2.1.6")]
[assembly: AssemblyFileVersion("2.1.6")]
[assembly: AssemblyInformationalVersion("2.1.6 Stable 1155 2.1/develop (d43870dd5)")]
#endif